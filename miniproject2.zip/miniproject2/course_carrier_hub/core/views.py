from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from .models import Student, AptitudeQuestion, AptitudeResult, Feedback, JobReferral
from .forms import StudentForm, FeedbackForm, JobReferralForm  # We'll create forms.py next
from django import forms

# Home/Dashboard
def home(request):
    return render(request, 'home.html')

# Student Registration
def register_student(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        student_form = StudentForm(request.POST, request.FILES)
        if form.is_valid() and student_form.is_valid():
            user = form.save()
            student = student_form.save(commit=False)
            student.user = user
            student.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
        student_form = StudentForm()
    return render(request, 'register.html', {'form': form, 'student_form': student_form})

# Aptitude Test
@login_required
def aptitude_test(request):
    questions = AptitudeQuestion.objects.all()
    if request.method == 'POST':
        score = 0
        for q in questions:
            selected = request.POST.get(f'question_{q.id}')
            if selected == q.correct_option:
                score += 1
        AptitudeResult.objects.create(student=request.user.student, score=score)
        return redirect('test_result', score=score)
    return render(request, 'aptitude_test.html', {'questions': questions})

def test_result(request, score):
    return render(request, 'test_result.html', {'score': score})

# Feedback Submission
@login_required
def submit_feedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.student = request.user.student
            feedback.save()
            return redirect('home')
    else:
        form = FeedbackForm()
    return render(request, 'feedback.html', {'form': form})

# Job Referral List and Create
@login_required
def job_referrals(request):
    jobs = JobReferral.objects.all()
    return render(request, 'job_referrals.html', {'jobs': jobs})

@login_required
def create_referral(request):
    if request.method == 'POST':
        form = JobReferralForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('job_referrals')
    else:
        form = JobReferralForm()
    return render(request, 'create_referral.html', {'form': form})

# Refer a job to a student (example view)
@login_required
def refer_job(request, job_id, student_id):
    job = get_object_or_404(JobReferral, id=job_id)
    student = get_object_or_404(Student, id=student_id)
    job.referred_student = student
    job.save()
    return redirect('job_referrals')