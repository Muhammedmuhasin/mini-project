from django import forms
from .models import Student, Feedback, JobReferral

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['full_name', 'email', 'phone', 'resume']

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['feedback_text', 'rating']

class JobReferralForm(forms.ModelForm):
    class Meta:
        model = JobReferral
        fields = ['title', 'company', 'description']