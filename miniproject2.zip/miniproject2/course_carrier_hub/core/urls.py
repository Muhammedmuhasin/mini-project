from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register_student, name='register'),
    path('aptitude_test/', views.aptitude_test, name='aptitude_test'),
    path('test_result/<int:score>/', views.test_result, name='test_result'),
    path('feedback/', views.submit_feedback, name='feedback'),
    path('job_referrals/', views.job_referrals, name='job_referrals'),
    path('create_referral/', views.create_referral, name='create_referral'),
    path('refer_job/<int:job_id>/<int:student_id>/', views.refer_job, name='refer_job'),
]