from django.contrib import admin
from .models import Student, AptitudeQuestion, AptitudeResult, Feedback, JobReferral

admin.site.register(Student)
admin.site.register(AptitudeQuestion)
admin.site.register(AptitudeResult)
admin.site.register(Feedback)
admin.site.register(JobReferral)