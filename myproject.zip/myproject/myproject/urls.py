
from django.urls import path
from myapp import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('',views.index,name="index" ),
    path('login',views.login,name="login" ),
    path('registration',views.registration,name="registration" ),
    path('register',views.register,name="register" ),
    path('login_action',views.login_action,name="login_action" ),
    path('logout_view',views.logout_view,name="logout_view" ),
    path('admin_home',views.admin_home,name="admin_home" ),
    path('user_home',views.user_home,name="user_home" ),
    path('userlist',views.userlist,name="userlist" ),
    path('addbook',views.addbook,name="addbook" ),
    path('booklist',views.booklist,name="booklist" ),
    path('delete_book/<int:id>',views.delete_book,name="delete_book" ),
    path('edit_book/<int:id>',views.edit_book,name="edit_book" ),
    path('update_book',views.update_book,name="update_book" ),
    path('profile',views.profile,name="profile" ),    
    path('update_profile',views.update_profile,name="update_profile" ),
    path('update_profile_action',views.update_profile_action,name="update_profile_action" ),
    path('books',views.books,name="books" ),
    path('more/<int:id>/', views.more, name='more'),


]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
